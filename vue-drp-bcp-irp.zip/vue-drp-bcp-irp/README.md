# IT Auditing Blog — DRP vs BCP vs IRP (Vue 3 + Vite)
See instructions inside. Run `npm install` then `npm run dev`.
